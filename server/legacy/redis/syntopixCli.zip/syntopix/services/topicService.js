const RedisService = require('./redisService');
const { ask } = require('../commands/readline');
const { queryArray } = require('../helpers');

// Create the minimal topic document in the topics stream
function createDocument(topicStreamKey) {
  return RedisService.addToStream(
    topicStreamKey,
    '*',
    'creator',
    Date.now()
  ).then((streamId) => ({
    streamId,
    pk: streamId,
  }));
}

// Add the full topic content to a Redis hash
function addTopicContent({
  streamId,
  title,
  summary,
  isPrivateFlag,
  topicContentKey,
  pk,
}) {
  if (!streamId || !title) {
    throw new Error('Invalid arguments: streamId and title are required');
  }

  const topicKey = `${topicContentKey}:${streamId}`;
  const value = {
    title,
    summary: summary || 'No summary provided',
    isPrivate: isPrivateFlag,
    createdBy: pk,
  };

  return RedisService.setHash(topicKey, value).then(() => {
    console.log(`Topic content added under key: ${topicKey}`);
    return { streamId, title };
  });
}

// Update the PK-to-Topic mapping
function updatePkTopics(pkTopicsKey, id, title) {
  return RedisService.setHashField(pkTopicsKey, id, title).then((result) => {
    if (result === 0) {
      console.warn(`No updates made to ${pkTopicsKey} for id ${id}`);
    }
    return result;
  });
}

// Pick a topic by index or title
function pickTopic(defaultTopicTitle, topics) {
  return ask('Enter Topic [by index or Title]:', defaultTopicTitle, 1).then(
    (topicTitle) => {
      console.log('\tConfirming Topic:>> ', topicTitle);

      const topic = queryArray(
        topicTitle,
        (t) => t.title === topicTitle,
        topics
      );

      // If no topic is found, create a new one
      if (!topic) {
        console.warn(`Topic "${topicTitle}" not found. Creating a new topic.`);
        return {
          id: `new-${Date.now()}`,
          title: topicTitle,
          Spaces: [],
        };
      }

      const { id, title, Spaces } = topic;
      return { id, title, Spaces };
    }
  );
}

// Fetch topics for a given PK
function fetchTopicsForPk(pkTopicsKey, topicContentKey) {
  if (!pkTopicsKey || !topicContentKey) {
    throw new Error(
      'Invalid arguments: pkTopicsKey and topicContentKey are required.'
    );
  }

  return RedisService.getHashContent(pkTopicsKey)
    .then((topics) => {
      if (!topics || Object.keys(topics).length === 0) {
        console.log(`No topics found for PK key: ${pkTopicsKey}`);
        return []; // Return an empty array if no topics are found
      }

      const topicKeys = Object.keys(topics);

      return Promise.all(
        topicKeys.map((id) => {
          const topicKey = `${topicContentKey}:${id}`;
          return RedisService.getHashContent(topicKey)
            .then((content) => {
              if (!content || Object.keys(content).length === 0) {
                console.warn(`No content found for topic ID: ${id}`);
                return { id, title: 'Untitled' }; // Default to 'Untitled' if content is missing
              }

              return {
                id,
                title: content.title || 'Untitled', // Default title if none provided
              };
            })
            .catch((err) => {
              console.error(
                `Error fetching content for topicKey: ${topicKey}`,
                err
              );
              return { id, title: 'Error fetching content' }; // Handle errors gracefully
            });
        })
      );
    })
    .catch((err) => {
      console.error(`Error fetching topics for PK key: ${pkTopicsKey}`, err);
      throw err; // Re-throw the error to ensure it can be handled by the caller
    });
}

// Fetch spaces for a given topic
function fetchSpacesForTopic(id, topicSpaceKey) {
  const thisTopicSpacesKey = `${topicSpaceKey}:${id}:spaces`;

  return RedisService.getSetMembers(thisTopicSpacesKey)
    .then((topicSpaces) => topicSpaces)
    .catch((err) => {
      console.error(`Error fetching spaces for topic ID: ${id}`, err);
      throw err;
    });
}

// Scan topics in the database
function scanTopics(keysMan) {
  const { topicStreamKey, topicContentKey } = keysMan;

  if (!topicStreamKey || !topicContentKey) {
    throw new Error('Missing required keys for scanTopics');
  }

  const results = [];
  let cursor = '0';

  const scan = () => {
    return RedisService.scanKeys(`${topicContentKey}:*`, cursor).then((res) => {
      cursor = res[0];
      const keys = res[1];
      results.push(...keys);

      if (cursor !== '0') {
        return scan();
      } else {
        return results;
      }
    });
  };

  return scan().then((keys) => {
    const promises = keys.map((key) => {
      return RedisService.getHashContent(key).then((content) => ({
        key,
        content,
      }));
    });

    return Promise.all(promises).then((topics) => topics);
  });
}

function addTopicCore({
  streamId,
  title,
  summary,
  isPrivateFlag,
  topicContentKey,
  pkTopicsKey,
  pk,
}) {
  return addTopicContent({
    streamId,
    title,
    summary,
    isPrivateFlag,
    topicContentKey,
    pk,
  })
    .then(() => updatePkTopics(pkTopicsKey, streamId, title))
    .then(() => ({
      streamId,
      title,
    }))
    .catch((err) => {
      console.error('Error in addTopicCore:', err);
      throw err;
    });
}

/*
1) remove a Topic from the Topics page
     a) removes the topic from the database
     b) removes the topicId from the spaces key for the pk
          19:tensor:spaces:1735954146712-0:First:topics
     c) removes the Space name from the topics key
          19:tensor:topics:1736561477990-0:spaces
2) removing a Topic from a Space should be limited to the Space.

First, use the PK hash
19:tensor:pks:1735954146712-0:topics
to remove the Topic ID

Next, from a PK's SET
19:tensor:spaces:1735954146712-0:First:topics
remove the Topic member 1736561477990-0

Finally, delete
SET 19:tensor:topics:1736626750755-0:spaces
and
HASH 19:tensor:topics:content:1736626750755-0
*/
async function deleteTopic({ id, keysMan }) {
  const { pkTopicsKey, topicSpaceKey, topicContentKey } = keysMan;

  // Step 1: Remove Topic ID from PK hash
  await RedisService.removeFromHash(pkTopicsKey, id);

  // Step 2: Fetch associated Spaces and remove Topic from them
  const topicSpacesKey = `${topicSpaceKey}:${id}:spaces`;
  const spaces = await RedisService.getSetMembers(topicSpacesKey);

  for (const spaceName of spaces) {
    // Remove Topic from Space's SET
    const spaceTopicsKey = `${keysMan.spaceKey}:${spaceName}:topics`;
    await RedisService.removeFromSet(spaceTopicsKey, id);

    // Remove Space name from Topic's spaces SET
    await RedisService.removeFromSet(topicSpacesKey, spaceName);
  }

  // Step 3: Delete Topic's spaces key
  await RedisService.removeFromSet(topicSpacesKey);

  // Step 4: Delete Topic's content hash
  const topicContentHash = `${topicContentKey}:${id}`;
  await RedisService.removeFromHash(topicContentHash);
}
async function deleteTopicFromSpace({ id, fromSpace, keysMan }) {
  // e.g., id=1736798780655-0
  //       19:tensor:topics:1736798780655-0:spaces
  //       19:tensor:spaces:1735954146712-0:a:topics
  const { topicSpaceKey } = keysMan;

  const spaceTopicsKey = `${keysMan.spaceKey}:${fromSpace}:topics`;
  const topicSpacesKey = `${topicSpaceKey}:${id}:spaces`;

  console.warn(
    `audit: Attempting to remove ${id} from spaceTopicsKey: ${spaceTopicsKey}`
  );

  const removedFromSpace = await RedisService.removeFromSet(spaceTopicsKey, id);

  if (!removedFromSpace) {
    console.warn(
      `audit: Topic ${id} was not in spaceTopicsKey: ${spaceTopicsKey}`
    );
  }

  console.warn(
    `audit: Attempting to remove ${fromSpace} from topicSpacesKey: ${topicSpacesKey}`
  );
  // Remove Space name from Topic's spaces SET
  const removedFromTopic = await RedisService.removeFromSet(
    topicSpacesKey,
    fromSpace
  );

  if (!removedFromTopic) {
    console.warn(
      `audit: Space ${fromSpace} was not in topicSpacesKey: ${topicSpacesKey}`
    );
  }

  console.warn(
    `audit: Completed deletion of topic ${id} from space ${fromSpace}`
  );
}

module.exports = {
  createDocument,
  addTopicContent,
  updatePkTopics,
  pickTopic,
  fetchTopicsForPk,
  fetchSpacesForTopic,
  scanTopics,
  addTopicCore,
  deleteTopic,
  deleteTopicFromSpace,
};
