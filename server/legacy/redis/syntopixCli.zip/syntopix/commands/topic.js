const topicService = require('../services/topicService');

/**
 * Adds a new topic.
 *
 * @param {Object} keysMan - The keys manager object.
 * @param {Object} data - Data containing title and summary.
 * @returns {Promise<Object>} - Resolves with the streamId and title on success.
 */
function addTopic(keysMan, data) {
  const { title, summary } = data;

  return topicService.createDocument(keysMan.topicStreamKey)
    .then(({ streamId }) => {
      const isPrivateFlag = '0';
      return topicService.addTopicCore({
        streamId,
        title,
        summary,
        isPrivateFlag,
        topicContentKey: keysMan.topicContentKey,
        pkTopicsKey: keysMan.pkTopicsKey,
        pk: keysMan.pk,
      });
    })
    .then(({ streamId, title }) => ({
      success: true,
      message: `Topic "${title}" added successfully. ${streamId}`,
    }))
    .catch((err) => ({
      success: false,
      error: err.message,
    }));
}

function getTopicsForPk(keysMan) {
  const { pkTopicsKey, topicContentKey } = keysMan;
  return topicService.fetchTopicsForPk(pkTopicsKey, topicContentKey);
}

function getTopicSpaces({ id, topicSpaceKey }) {
  return topicService.fetchSpacesForTopic(id, topicSpaceKey);
}

function listTopicSpaces(keysMan) {
  return getTopicsForPk(keysMan)
    .then((topics) => {
      if (!topics || topics.length === 0) {
        console.log(`No topics found for PK: ${keysMan.pk}`);
        return [];
      }
      const topicSpaceKey = keysMan.topicSpaceKey;
      return Promise.all(
        topics.map(({ id, title, summary }) =>
          getTopicSpaces({ id, topicSpaceKey }).then((spaces) => ({
            id,
            title,
            summary,
            Spaces: spaces.join(', '),
          }))
        )
      );
    })
    .then((detailedTopics) => {
      if (!detailedTopics || detailedTopics.length === 0) {
        console.log('\nNo topics with associated spaces found.');
        return [];
      }

      console.log('\nTopics and their Spaces:');
      console.table(detailedTopics);
      return detailedTopics;
    })
    .catch((err) => {
      console.error('Error listing topic spaces:', err);
    });
}

function deleteTopic({ id, keysMan }) {
  return topicService.deleteTopic({ id, keysMan });
}

function deleteTopicFromSpace({ id, fromSpace, keysMan }) {
  return topicService.deleteTopicFromSpace({ id, fromSpace, keysMan });
}

module.exports = {
  addTopic,
  getTopicsForPk,
  getTopicSpaces,
  listTopicSpaces,
  deleteTopic,
  deleteTopicFromSpace,
};
